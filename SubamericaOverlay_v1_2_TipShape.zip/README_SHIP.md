# Subamerica Overlay — Ship-Ready Package

This bundle includes a fixed BrightScript entry (`source/main.brs`) and documentation.

## What Changed
- Replaced corrupted `source/main.brs` with a hardened version:
  - HTTPS certs & 10s connection timeout
  - Defensive JSON parsing and clear logs
  - Optional support for `qrUri` and `visible` JSON fields
- Left all other files intact.

## How It Works
- App polls `https://sub-relay-server.onrender.com/poll` every 5s.
- Expects JSON: `{"text":"..."};` updates `MainScene.tipText`.
- (Optional) `{"qrUri":"https://...","visible":true}` updates QR Poster and visibility.

## Test Checklist
- Sideload and confirm the label updates within ~5–10s when server returns `{"text":"hello"}`.
- Non-200 or invalid JSON logs are visible on telnet `:8085`.


## v1.1 Resilience
- Accepts many JSON shapes (text/message/msg, nested under data, arrays, or plain string)
- Shows default CTA if no usable text is present

- v1.2: Added support for {'type':'tip','emoji':'🎵','amount':<number>} payloads.
